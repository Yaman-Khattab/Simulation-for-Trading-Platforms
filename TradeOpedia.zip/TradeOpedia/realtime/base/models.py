from curses.ascii import NUL
from email.policy import default
from operator import truediv
from unicodedata import name
from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
# Create your models here.


class Industry(models.Model):
    industry_type = (
        ('cryptocurrencies', 'Cryptocurrencies'),
        ('currencies','Currencies'),
        ('stocks', 'Stocks'),
        ('commodities','Commodities')
    )
    id = models.AutoField(primary_key=True, unique=True)
    industry_name = models.TextField(null=True, blank=True)
    price = models.TextField(null=True, blank=True)
    typet = models.CharField(max_length=20,choices=industry_type, null=True, blank=True)
    icon = models.ImageField(null = True, blank = True)
    

    def __str__(self):
        return self.industry_name

class Wallet(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    amount = models.DecimalField(max_digits=10,decimal_places=2, null=True, blank=True, default=10000)

    def __str__(self):
        return self.user.username

class Trade(models.Model):
    trade_type = (
        ('buy', 'Buy'),
        ('sell','Sell')
    )

    trade_status = (
        ('active', 'Active'),
        ('notactive','Not Active')
    )
    id = models.AutoField(primary_key=True)
    open_time = models.DateTimeField(default= timezone.now)
    open_value = models.DecimalField(max_digits=10,decimal_places=2, null=True, blank=True)
    units = models.DecimalField(max_digits=10,decimal_places=2, null=True, blank=True)
    indus_name = models.ForeignKey(Industry, on_delete=models.CASCADE, null=True)
    Tuser = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    TypeTrade = models.CharField(max_length=20,choices=trade_type, null=True, blank=True)
    trade_amount = models.DecimalField(max_digits=10,decimal_places=2, null=True, blank=True)
    status = models.CharField(max_length=20,choices=trade_status, null=True, blank=True)
    take_profit = models.FloatField(null=True, blank=True)
    stop_loss = models.FloatField(null=True, blank=True)
    current_profit_loss = models.DecimalField(max_digits=15,decimal_places=2, null=True, blank=True)
    closed_profit_loss = models.DecimalField(max_digits=15,decimal_places=2, null=True, blank=True)
        
    def __str__(self):
        return  str(self.id) + " " +self.Tuser.username + "-" + self.indus_name.industry_name

class Wishlist(models.Model):
    industry_id = models.ManyToManyField(Industry, blank=True, null=True)
    wishlist_id = models.AutoField(primary_key=True, unique=True)
    id_W = models.OneToOneField(User, on_delete = models.CASCADE)

    def __str__(self):
        return self.id_W.username

class HistoryTrades(models.Model):
    trade_type = (
        ('buy', 'Buy'),
        ('sell','Sell')
    )


    open_time = models.DateTimeField(default= timezone.now)
    close_time = models.DateTimeField(null=True, blank=True)
    open_value = models.DecimalField(max_digits=10,decimal_places=2, null=True, blank=True)
    close_value = models.DecimalField(max_digits=10,decimal_places=2, null=True, blank=True)
    units = models.DecimalField(max_digits=10,decimal_places=2, null=True, blank=True)
    indus_name = models.ForeignKey(Industry, on_delete=models.CASCADE, null=True)
    Tuser = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    TypeTrade = models.CharField(max_length=20,choices=trade_type, null=True, blank=True)
    trade_amount = models.DecimalField(max_digits=10,decimal_places=2, null=True, blank=True)
    take_profit = models.DecimalField(max_digits=10,decimal_places=2, null=True, blank=True)
    stop_loss = models.DecimalField(max_digits=10,decimal_places=2, null=True, blank=True)
    closed_profit_loss = models.DecimalField(max_digits=10,decimal_places=2, null=True, blank=True)
        
    def __str__(self):
        return self.Tuser.username + "-" + self.indus_name.industry_name

class Notification(models.Model):

    mtype = (
        ('seen', 'Seen'),
        ('notseen','Not Seen')
    )


    Nuser = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    message = models.TextField(null=True, blank=True)
    message_time = models.DateTimeField(default= timezone.now)
    messagetype = models.CharField(max_length=20,choices=mtype, null=True, blank=True)

    def __str__(self):
        return str(self.id) + " " + str(self.Nuser.username)


class Images(models.Model):
    icon = models.ImageField(null = True, blank = True)

    def __str__(self):
        return str(self.id)



