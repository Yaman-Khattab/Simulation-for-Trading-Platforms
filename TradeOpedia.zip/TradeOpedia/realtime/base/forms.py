from dataclasses import field, fields
from django import forms
from django.forms import ModelForm
from .models import Industry, User, Wallet, Trade, Wishlist
from django.contrib.auth.forms import  UserCreationForm, UserChangeForm


class CreateUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username','first_name','last_name','email', 'password1','password2']

class UpdateForm(UserChangeForm):
    class Meta:
        model = User
        fields = (
            'email',
            'first_name',
            'last_name',
            'password'
        )
class Walletform(ModelForm):
    class Meta:
        model = Wallet
        fields = ['amount']

class TradeForm(ModelForm):
    class Meta:
        model = Trade
        fields = ['trade_amount','status','take_profit','stop_loss','current_profit_loss','closed_profit_loss']

class IndustryForm(ModelForm):
    class Meta:
        model = Industry
        fields = ['industry_name']

class TradeForm(ModelForm):
    class Meta:
        model = Trade
        fields = ['trade_amount','status','take_profit','stop_loss','current_profit_loss','closed_profit_loss']


class watchlistForm(ModelForm):
    class Meta:
        model = Wishlist
        fields = ['id_W']

