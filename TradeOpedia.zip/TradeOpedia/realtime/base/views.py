from ast import Delete
from asyncio import constants
import re
from turtle import xcor
from django.shortcuts import render
from multiprocessing import connection, context
from celery import shared_task
import requests
from celery import shared_task
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from bs4 import BeautifulSoup
import aiohttp
import yfinance as yf
import asyncio
import csv
import datetime
import datetime as dt
import json
import logging
import threading
from webbrowser import get
import aiohttp
import lxml.html
import numpy as np
import pandas as pd
from .models import Industry
import requests
import websocket
import yfinance as yf
from bs4 import BeautifulSoup
from django.http import HttpResponse
from lxml.html.soupparser import fromstring
from asgiref.sync import sync_to_async

from django import urls
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import redirect, render
from .forms import CreateUserForm, TradeForm, UpdateForm, Walletform, IndustryForm, watchlistForm
from .models import Industry, User, Wallet,Trade,Wishlist, HistoryTrades, Notification,Images
from datetime import date , timedelta
from django.utils import timezone

notifcLogo = Images.objects.get(id = 4)
TradeopediaLogo = Images.objects.get(id = 5)

@login_required(login_url="login")
def mainpage(request):
    if request.user.is_authenticated:
        return redirect("home")
    else:
        return redirect("login")

@login_required(login_url="login")
def home(request):
    user = request.user
    info1 = Notification.objects.all()
    info1 = info1.filter(Nuser = request.user)
    watchl = Wishlist.objects.get(id_W = user.id)
    watchl = watchl.industry_id.all()
    wallet = Wallet.objects.get(user = user)
    totalinvested = 0
    totalprofitLoss = 0

    current_trades = Trade.objects.all()
    for x in current_trades:
        xx = str(x).split("-")
        in1 = Industry.objects.get(industry_name = xx[1])
        curr1 = current_trades.filter(Tuser = request.user , indus_name = in1, id = x.id)
        for h in curr1: 
            totalinvested = totalinvested + h.trade_amount
            totalprofitLoss = totalprofitLoss + h.current_profit_loss
    
    totalwallet = wallet.amount
    cashAvailable = totalwallet + totalinvested

    cashAvailable = "{:,}".format(cashAvailable)
    #totalwallet = "{:,}".format(totalwallet)
    totalinvested = "{:,}".format(totalinvested)
    totalprofitLoss = "{:,}".format(totalprofitLoss)

 
    y1 = []
    y3 = []
    y4 = []

    x1 = []
    x2 = []
    x3 = []
    
    industry = Industry.objects.all()

    for xx in industry:
       
        if str(xx.typet) == "cryptocurrencies":
            y1.append(xx)
            flag = 0
            for i in watchl:
                if str(i) == str(xx):
                    x1.append(xx)
                    flag = 1
                    break
            if flag == 0:
                x1.append("0")

            
            

        if str(xx.typet) == "stocks":
            y3.append(xx)
            flag = 0
            for i in watchl:
                if str(i) == str(xx):
                    x2.append(xx)
                    flag = 1
                    break
            if flag == 0:
                x2.append("0")

        if str(xx.typet) == "commodities":
            y4.append(xx)
            flag = 0
            for i in watchl:
                if str(i) == str(xx):
                    x3.append(xx)
                    flag = 1
                    break
            if flag == 0:
                x3.append("0")
            
    context = {"user": user, "cryptocurrencies": y1, 
    "stocks":y3, "commodities":y4, "info1":info1, 
    "NotificationLogo":notifcLogo, "tradeOpedia":TradeopediaLogo, "x1":x1, "x2":x2, "x3":x3, "cashAvailable":cashAvailable,"totalwallet": totalwallet, "totalinvested":totalinvested, "totalprofitLoss":totalprofitLoss}
        
    
    if request.method == 'POST':
        if 'q' in request.POST:
            y1 = []
            y3 = []
            y4 = []
            q = request.POST['q']
            print(q)
            industry = Industry.objects.filter(industry_name__icontains= str(q))
            user = request.user
            for xx in industry:
    
                if str(xx.typet) == "cryptocurrencies":
                    y1.append(xx)

                if str(xx.typet) == "stocks":
                    y3.append(xx)
                if str(xx.typet) == "commodities":
                    y4.append(xx)
            
    
            context = {"user": user, "cryptocurrencies": y1, "stocks":y3, "commodities":y4, "NotificationLogo":notifcLogo, "tradeOpedia":TradeopediaLogo}
            return render(request,"base/home.html", context)

    if request.method == 'POST':

        # CHECK wlist duplicated!
        wlist = Industry.objects.all()
        for qq in wlist:
            if "remove" in request.POST:
                xx = request.POST.get("remove")
                print("Remove!!1")
                print(xx)
                wlist = Wishlist.objects.get(id_W = request.user)
                wlist.industry_id.remove(Industry.objects.get(industry_name = str(xx)))
                wlist.save()
                return redirect("home")
            elif "add" in request.POST:
                xx = request.POST.get("add")
                print("Add here")
                print(xx)
                wlist = Wishlist.objects.get(id_W = request.user)
                wlist.industry_id.add(Industry.objects.get(industry_name = str(xx)))
                wlist.save()
                return redirect("home")
           
    return render(request,"base/home.html", context)


@login_required(login_url="login")
def Portfolio(request):
    
    current_trades = HistoryTrades.objects.all()
    h1 = []
    total = 0.00
    for x in current_trades:
        xx = str(x).split("-")
        in1 = Industry.objects.get(industry_name = xx[1])
        curr1 = current_trades.filter(Tuser = request.user , indus_name = in1, id = x.id)
        
        for h in curr1:  
            total = float(total) + float(h.closed_profit_loss)
            h1.append(h)
    total = format(total,".2f")
    #return render(request, "base/TradeHistory.html", context)
    
    
    
    current_trades = Trade.objects.all()
    uwallet = Wallet.objects.get(user = request.user)
    hh = []
    stoplossvalues = []
    ids = []
    tamount = 0.0
    for x in current_trades:
        xx = str(x).split("-")
        in1 = Industry.objects.get(industry_name = xx[1])
        curr1 = current_trades.filter(Tuser = request.user , indus_name = in1, id = x.id)
        for h in curr1: 
            stoplossvalues.append(h.stop_loss)
            ids.append(h.id)
            hh.append(h)
            if request.method == 'POST':
                tamount = h.trade_amount
                price1 = Industry.objects.get(industry_name = h.indus_name)
                if str(h.indus_name) in request.POST:
                    history = HistoryTrades(Tuser = h.Tuser, indus_name = h.indus_name, close_time = timezone.now(), open_value = h.open_value, close_value = float(price1.price), units = h.units, TypeTrade = h.TypeTrade,trade_amount = h.trade_amount, take_profit = h.take_profit, stop_loss = h.stop_loss, closed_profit_loss = h.current_profit_loss)  
                    history.save()
                    uwallet.amount = float(uwallet.amount) + float(h.trade_amount) + float(h.current_profit_loss)
                    uwallet.save()
                    h.delete()
                    return redirect("Portfolio")
                if "edit" in request.POST:
                    tp = request.POST.get("take_profit")
                    sl = request.POST.get("stop_loss")
                    if(float(sl) <= tamount/2):
                        h.take_profit = float(tp)
                        h.stop_loss = float(sl) * float(-1) 
                        h.save()
                    else:
                        messages.error(request, "stop loss is greater than Half of the ammount!!")
                    
                    return redirect("Portfolio")
    
    user = request.user
    wallet = Wallet.objects.get(user=user.id)
    context = {"user": user, "wallet": wallet, "data": hh, "NotificationLogo":notifcLogo, "tradeOpedia":TradeopediaLogo, 
    "stoplossvalues":stoplossvalues, "ids":ids, "h1": h1, "total": total}
    return render(request, "base/portfolio.html", context)

@login_required(login_url="login")
def History(request):
    #history = HistoryTrades(Tuser = request.user, indus_name = Industry.objects.get(industry_name = "BITCOIN"))
    #history.save()
    current_trades = HistoryTrades.objects.all()
    hh = []
    total = 0.00
    for x in current_trades:
        xx = str(x).split("-")
        in1 = Industry.objects.get(industry_name = xx[1])
        curr1 = current_trades.filter(Tuser = request.user , indus_name = in1, id = x.id)
        
        for h in curr1:  
            total = float(total) + float(h.closed_profit_loss)
            hh.append(h)
    total = format(total,".2f")
    context = {"data": hh,"NotificationLogo":notifcLogo, "tradeOpedia":TradeopediaLogo, "total": total}
    return render(request, "base/TradeHistory.html", context)

@login_required(login_url="login")
def Prediction(request):
    pathRequest = "BITCOIN"
    pathh = "Historical_Prices/" + str(pathRequest) + ".csv"
    file = open(pathh)
    csvreader = csv.reader(file)
    rows = []
    cpt = 0
    for row in csvreader:
        if row[0] != "Date":
            element1 = datetime.datetime.strptime(row[0], "%Y-%m-%d")
            timestamp1 = datetime.datetime.timestamp(element1)
            rows.append(str(int(timestamp1)) + ";")
            rows.append(str(row[1]) + ";")
            rows.append(str(row[2]) + ";")
            rows.append(str(row[3]) + ";")
            rows.append(str(row[4]) + ";")
            cpt += 5

    file.close()
    context = {"data": rows,"NotificationLogo":notifcLogo, "tradeOpedia":TradeopediaLogo}
    return render(request, "base/prediction.html",context)   
    

def signupform(request):
    if request.user.is_authenticated:
        return redirect("home")
    else:
        form = CreateUserForm()
        userWallet = Walletform()
        watchlistuser = watchlistForm()
        if request.method == "POST":
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.save()

                profile = userWallet.save(commit=False)
                profile.user = user
                profile.save()

                wlist = watchlistuser.save(commit=False)
                wlist.id_W = user
                wlist.save()
                
                xuser = form.cleaned_data.get("username")
                messages.success(request, "Account was created for " + xuser)
                return redirect("login")

        context = {"form": form, "tradeOpedia":TradeopediaLogo}
        return render(request, "base/signup.html", context)


@login_required(login_url="login")
def updateUser(request):
    if request.method == "POST":
        if "changepss" in request.POST:
            u = User.objects.get(username= request.user)
            #pass0 = request.POST.get("pss0")
            pass1 = request.POST.get("pss1")
            pass2 = request.POST.get("pss2")
            
            if pass1 == pass2:
                u.set_password(pass1)
                u.save()
                return redirect("login")
            else:
                messages.error(request, "Please make sure your passwords match!")
                return render(request, "base/pass.html")

        form = UpdateForm(request.POST, instance=request.user)

        if form.is_valid():
            form.save()
            return redirect("home")
    else:
        form = UpdateForm(instance=request.user)
        context = {"form": form,"NotificationLogo":notifcLogo, "tradeOpedia":TradeopediaLogo}
        return render(request, "base/update.html", context)


def loginPage(request):
    context = {"tradeOpedia":TradeopediaLogo}

    if request.user.is_authenticated:
        return redirect("home")
    else:
        if request.method == "POST":
            username = request.POST.get("username")
            password = request.POST.get("password")

            try:
                user = User.objects.get(username=username)
            except:
                messages.error(request, "Invalid Username or password")

            
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect("home")
            else:
                messages.error(request, "Invalid Username or password")
        return render(request,"base/login.html", context)


def logoutUser(request):
    logout(request)
    return redirect("login")


@login_required(login_url="login")
def watchlist(request):
    
    wl = []
    wlist = Wishlist.objects.get(id_W = request.user)
    xy = wlist.industry_id.all()
    for qq  in xy:
        xx = request.POST.get(str(qq))
        
        if "remove" in request.POST:
                xx = request.POST.get("remove")
                wlist = Wishlist.objects.get(id_W = request.user)
                wlist.industry_id.remove(Industry.objects.get(industry_name = str(xx)))
                wlist.save()
                return redirect("watchlist")
        wl.append(qq)
    context = {"wishlist":wl,"NotificationLogo":notifcLogo, "tradeOpedia":TradeopediaLogo}
    return render(request, "base/watchlist.html", context)


@login_required(login_url="login")
def trade(request, name):
    
    Date_req = date.today() + timedelta(days=1)
    pathRequest = str(request.path)
    pathRequest = pathRequest.replace("/trade/", "")
    pathRequest = pathRequest.replace("/", "")

    index = ["BTC-USD", "ETH-USD" , "TSLA", "FB", "NFLX", "NVDA","AMZN","CL=F", "MGC=F", "NG=F"]
    name = ["BITCOIN", "ETHEREUM", "TESLA", "FACEBOOK", "NETFLIX", "NVIDIA", "AMAZON", "OIL","GOLD","NATGAS"]
    if pathRequest not in name:
        return redirect("home")

    indexx = name.index(pathRequest)

    upt_data = yf.download(index[indexx], start="2022-04-27", end=Date_req)
    sf = upt_data["Close"]
    fd = pd.DataFrame({"Date": sf.index, "Values": sf.values})

    pathh = "Historical_Prices/" + str(pathRequest) + ".csv"
    file = open(pathh)
    csvreader = csv.reader(file)
    rows = []
    cpt = 0
    for row in csvreader:
        if row[0] != "Date":
            element1 = datetime.datetime.strptime(row[0], "%Y-%m-%d")
            timestamp1 = datetime.datetime.timestamp(element1)
            rows.append(str(int(timestamp1)) + ";")
            rows.append(str(row[1]) + ";")
            rows.append(str(row[2]) + ";")
            rows.append(str(row[3]) + ";")
            rows.append(str(row[4]) + ";")
            cpt += 5

    file.close()

    updated_prices = []
    for i in range(0, len(fd["Date"])):
        yy = str(fd["Date"][i]).removesuffix(" 00:00:00")
        element = datetime.datetime.strptime(yy, "%Y-%m-%d")
        timestamp = datetime.datetime.timestamp(element)
        updated_prices.append(str(int(timestamp)) + ";")
        updated_prices.append(str(upt_data["Open"][i]) + ";")
        updated_prices.append(str(upt_data["High"][i]) + ";")
        updated_prices.append(str(upt_data["Low"][i]) + ";")
        updated_prices.append(str(upt_data["Close"][i]) + ";")

    arr = rows + updated_prices
    context = {"data": arr, "name": pathRequest, "NotificationLogo":notifcLogo, "tradeOpedia":TradeopediaLogo}

    if request.method == 'POST':
    
        form = TradeForm(request.POST, request.FILES)
        xind = Industry.objects.get(industry_name=pathRequest)
        uwallet = Wallet.objects.get(user = request.user)
        currentPrice = xind.price
        
        if float(uwallet.amount) - float(request.POST.get("trade_amount")) >= 0.0 and float(request.POST.get("trade_amount")) > 0 and float(request.POST.get("take_profit")) >=0 and float(request.POST.get("stop_loss")) >=0 and float(request.POST.get("trade_amount")) >= 100 and float(request.POST.get("stop_loss")) <= float(request.POST.get("trade_amount")) / 2:

            uwallet.amount = float(uwallet.amount) - float(request.POST.get("trade_amount"))
            uwallet.save()
            if form.is_valid():
                instance = form.save(commit=False)
                instance.trade_amount = float(request.POST.get("trade_amount"))
                instance.Tuser = request.user
                instance.indus_name = xind
                instance.open_value = float(currentPrice)
                instance.units = float(request.POST.get("trade_amount")) / float(currentPrice)
                instance.TypeTrade = request.POST.get("TradeType")
                instance.status = "active"
                if int(request.POST.get("stop_loss")) == int(0):
                    instance.stop_loss = (float(request.POST.get("trade_amount")) / float(2) ) * float(-1)
                else:
                    instance.stop_loss = float(request.POST.get("stop_loss")) * float(-1)
                
                if int(request.POST.get("take_profit")) == int(0):
                    instance.take_profit = (float(request.POST.get("trade_amount")) / float(2) )
                else:
                    instance.take_profit = float(request.POST.get("take_profit"))

                
                instance.current_profit_loss = float(0.0)
                instance.save()
                messages.error(request, str(pathRequest) + " Trade is Placed Successfully!")
                info = Notification(Nuser = request.user, message = str(pathRequest) + " Trade Placed Successfully!", messagetype = "notseen")
                info.save()
                
                context = {"data": arr, "name": pathRequest,"NotificationLogo":notifcLogo, "tradeOpedia":TradeopediaLogo}
                return render(request, "base/tradeform.html", context)
                
            else:
              
                messages.error(request, "form is not valid!")
                return render(request, "base/tradeform.html", context)

        else:
            if float(uwallet.amount) - float(request.POST.get("trade_amount")) < 0.0:
                messages.error(request, "The trade amount exceedes the money you have in the wallet!")

            elif float(request.POST.get("trade_amount")) < 100:
                messages.error(request, "Trade Amount Must Be at least 100$!")
            elif float(request.POST.get("stop_loss")) > float(request.POST.get("trade_amount")) / 2:
                messages.error(request, "Maximum Stop Loss is " + str(float(request.POST.get("trade_amount")) / 2))

            return render(request, "base/tradeform.html", context)
       

    return render(request, "base/tradeform.html", context)
