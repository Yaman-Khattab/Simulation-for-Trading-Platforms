from django.urls import path
from .consumers import  profit_loss_consumer, JokesConsumer


ws_urlpatterns = [
    path('ws/profloss/', profit_loss_consumer.as_asgi()),
    path('ws/jokes/', JokesConsumer.as_asgi())

]

