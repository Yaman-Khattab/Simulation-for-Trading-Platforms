from django.contrib import admin
from .models import User, Industry,Wallet,Trade,Wishlist, HistoryTrades, Notification,Images

# Register your models here.


#
admin.site.register(Industry)
admin.site.register(Wallet)
admin.site.register(Trade)
admin.site.register(Wishlist)
admin.site.register(HistoryTrades)
admin.site.register(Notification)
admin.site.register(Images)
